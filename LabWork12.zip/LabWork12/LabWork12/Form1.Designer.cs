﻿namespace l26
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.nameOfOrganization = new System.Windows.Forms.TextBox();
            this.here = new System.Windows.Forms.TextBox();
            this.txtTemplatePath = new System.Windows.Forms.TextBox();
            this.txtTermin = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.place = new System.Windows.Forms.TextBox();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.round = new System.Windows.Forms.TextBox();
            this.dis = new System.Windows.Forms.TextBox();
            this.ann = new System.Windows.Forms.TextBox();
            this.prot = new System.Windows.Forms.TextBox();
            this.txtSave = new System.Windows.Forms.TextBox();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.button3 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(648, 156);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(193, 34);
            this.button1.TabIndex = 3;
            this.button1.Text = "Згенерувати довідку";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.btnGenerateCertificate_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(649, 198);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(193, 34);
            this.button2.TabIndex = 4;
            this.button2.Text = "Обрати шаблон довідки";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.btnSelectTemplate_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // nameOfOrganization
            // 
            this.nameOfOrganization.Location = new System.Drawing.Point(8, 23);
            this.nameOfOrganization.Margin = new System.Windows.Forms.Padding(4);
            this.nameOfOrganization.Name = "nameOfOrganization";
            this.nameOfOrganization.Size = new System.Drawing.Size(557, 22);
            this.nameOfOrganization.TabIndex = 7;
            this.nameOfOrganization.Text = "название организации";
            // 
            // here
            // 
            this.here.Location = new System.Drawing.Point(8, 113);
            this.here.Margin = new System.Windows.Forms.Padding(4);
            this.here.Name = "here";
            this.here.Size = new System.Drawing.Size(557, 22);
            this.here.TabIndex = 10;
            this.here.Text = "присутствуют";
            // 
            // txtTemplatePath
            // 
            this.txtTemplatePath.Location = new System.Drawing.Point(607, 91);
            this.txtTemplatePath.Margin = new System.Windows.Forms.Padding(4);
            this.txtTemplatePath.Name = "txtTemplatePath";
            this.txtTemplatePath.Size = new System.Drawing.Size(235, 22);
            this.txtTemplatePath.TabIndex = 18;
            this.txtTemplatePath.Text = "Шлях для відкриття файлу";
            // 
            // txtTermin
            // 
            this.txtTermin.Location = new System.Drawing.Point(8, 83);
            this.txtTermin.Margin = new System.Windows.Forms.Padding(4);
            this.txtTermin.Name = "txtTermin";
            this.txtTermin.Size = new System.Drawing.Size(557, 22);
            this.txtTermin.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Britannic Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(857, 53);
            this.label1.TabIndex = 29;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.place);
            this.groupBox1.Controls.Add(this.dateTimePicker2);
            this.groupBox1.Controls.Add(this.round);
            this.groupBox1.Controls.Add(this.dis);
            this.groupBox1.Controls.Add(this.ann);
            this.groupBox1.Controls.Add(this.prot);
            this.groupBox1.Controls.Add(this.here);
            this.groupBox1.Controls.Add(this.nameOfOrganization);
            this.groupBox1.Controls.Add(this.txtTermin);
            this.groupBox1.Location = new System.Drawing.Point(13, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(573, 330);
            this.groupBox1.TabIndex = 30;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Інформація про збори";
            // 
            // place
            // 
            this.place.Location = new System.Drawing.Point(280, 150);
            this.place.Margin = new System.Windows.Forms.Padding(4);
            this.place.Name = "place";
            this.place.Size = new System.Drawing.Size(285, 22);
            this.place.TabIndex = 31;
            this.place.Text = "место проведения";
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.Location = new System.Drawing.Point(8, 148);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(265, 22);
            this.dateTimePicker2.TabIndex = 30;
            // 
            // round
            // 
            this.round.Location = new System.Drawing.Point(8, 237);
            this.round.Margin = new System.Windows.Forms.Padding(4);
            this.round.Name = "round";
            this.round.Size = new System.Drawing.Size(557, 22);
            this.round.TabIndex = 29;
            this.round.Text = "круглый стол";
            // 
            // dis
            // 
            this.dis.Location = new System.Drawing.Point(8, 207);
            this.dis.Margin = new System.Windows.Forms.Padding(4);
            this.dis.Name = "dis";
            this.dis.Size = new System.Drawing.Size(557, 22);
            this.dis.TabIndex = 28;
            this.dis.Text = "обсуждение";
            // 
            // ann
            // 
            this.ann.Location = new System.Drawing.Point(8, 177);
            this.ann.Margin = new System.Windows.Forms.Padding(4);
            this.ann.Name = "ann";
            this.ann.Size = new System.Drawing.Size(557, 22);
            this.ann.TabIndex = 27;
            this.ann.Text = "объявление";
            // 
            // prot
            // 
            this.prot.Location = new System.Drawing.Point(8, 53);
            this.prot.Margin = new System.Windows.Forms.Padding(4);
            this.prot.Name = "prot";
            this.prot.Size = new System.Drawing.Size(557, 22);
            this.prot.TabIndex = 25;
            this.prot.Text = "протокол";
            // 
            // txtSave
            // 
            this.txtSave.Location = new System.Drawing.Point(605, 123);
            this.txtSave.Margin = new System.Windows.Forms.Padding(4);
            this.txtSave.Name = "txtSave";
            this.txtSave.Size = new System.Drawing.Size(235, 22);
            this.txtSave.TabIndex = 32;
            this.txtSave.Text = "Шлях для збереження файлу";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(649, 240);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(193, 42);
            this.button3.TabIndex = 33;
            this.button3.Text = "Обрати місце збереження";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(857, 417);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.txtSave);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtTemplatePath);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "l26";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox nameOfOrganization;
        private System.Windows.Forms.TextBox here;
        private System.Windows.Forms.TextBox txtTemplatePath;
        private System.Windows.Forms.DateTimePicker txtTermin;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtSave;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox prot;
        private System.Windows.Forms.TextBox round;
        private System.Windows.Forms.TextBox dis;
        private System.Windows.Forms.TextBox ann;
        private System.Windows.Forms.TextBox place;
        private System.Windows.Forms.DateTimePicker dateTimePicker2;
    }
}

